﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication2.ViewModel;
using MvcApplication2.Models;

namespace MvcApplication2.Controllers
{
    public class LoginController : Controller
    {
        //
        // GET: /Login/
        public UserContext db = new UserContext();
        public ActionResult Index()
        {
            return View();
        }

   public ActionResult Create()
        {

            return View();
        }
        [HttpPost]
   public ActionResult Create(LoginViewModel lm)
   {
       var u = db.UserDemos.Where(x => x.uname == lm.Username & x.pwd == lm.Password).FirstOrDefault();
            if(u==null)
            {
                ModelState.AddModelError("", "Invalid username or password");
                return View();
            }
       return RedirectToAction("Index","Home");
   }
    }
}
